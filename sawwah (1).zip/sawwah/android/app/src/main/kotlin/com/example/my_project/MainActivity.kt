package com.mycompany.sawwah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
