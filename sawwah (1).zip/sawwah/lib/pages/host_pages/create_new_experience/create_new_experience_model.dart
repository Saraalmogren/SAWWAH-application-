import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/backend/schema/enums/enums.dart';
import '/components/pick_location_widget.dart';
import '/flutter_flow/flutter_flow_count_controller.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import '/pages/navbar_forhost/navbar_forhost_widget.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'create_new_experience_widget.dart' show CreateNewExperienceWidget;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CreateNewExperienceModel
    extends FlutterFlowModel<CreateNewExperienceWidget> {
  ///  Local state fields for this page.

  LatLng? locatIon;

  ///  State fields for stateful widgets in this page.

  final formKey1 = GlobalKey<FormState>();
  final formKey3 = GlobalKey<FormState>();
  final formKey2 = GlobalKey<FormState>();
  final formKey4 = GlobalKey<FormState>();
  final formKey5 = GlobalKey<FormState>();
  // Stores action output result for [Backend Call - API (mapsString)] action in CreateNewExperience widget.
  ApiCallResponse? api;
  // State field(s) for Experiencename1 widget.
  FocusNode? experiencename1FocusNode;
  TextEditingController? experiencename1TextController;
  String? Function(BuildContext, String?)?
      experiencename1TextControllerValidator;
  String? _experiencename1TextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'This field is required';
    }

    if (val.length < 3) {
      return 'Enter at least 3 characters';
    }

    return null;
  }

  // Stores action output result for [Backend Call - API (mapsString)] action in Button widget.
  ApiCallResponse? apiResultpzy;
  // State field(s) for Experience_about1 widget.
  FocusNode? experienceAbout1FocusNode;
  TextEditingController? experienceAbout1TextController;
  String? Function(BuildContext, String?)?
      experienceAbout1TextControllerValidator;
  String? _experienceAbout1TextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'This field is required';
    }

    if (val.length < 3) {
      return 'Description should be at least 3 characters';
    }

    return null;
  }

  // State field(s) for categoryPicker widget.
  FormFieldController<String>? categoryPickerValueController;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for SeatLimit widget.
  int? seatLimitValue;
  // State field(s) for AgeField1 widget.
  FormFieldController<String>? ageField1ValueController;
  // State field(s) for Gender widget.
  FormFieldController<String>? genderValueController;
  // State field(s) for PriceField1 widget.
  FocusNode? priceField1FocusNode;
  TextEditingController? priceField1TextController;
  String? Function(BuildContext, String?)? priceField1TextControllerValidator;
  String? _priceField1TextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'This field is required ';
    }

    if (val.length < 1) {
      return 'Enter at least 1 character';
    }
    if (val.length > 8) {
      return 'Enter less than 8 characters';
    }

    return null;
  }

  // State field(s) for TextField11 widget.
  FocusNode? textField11FocusNode;
  TextEditingController? textField11TextController;
  String? Function(BuildContext, String?)? textField11TextControllerValidator;
  DateTime? datePicked1;
  // State field(s) for TextField22 widget.
  FocusNode? textField22FocusNode;
  TextEditingController? textField22TextController;
  String? Function(BuildContext, String?)? textField22TextControllerValidator;
  DateTime? datePicked2;
  // Stores action output result for [Backend Call - API (geocode)] action in Button widget.
  ApiCallResponse? address;
  // Model for navbarForhost component.
  late NavbarForhostModel navbarForhostModel;

  @override
  void initState(BuildContext context) {
    experiencename1TextControllerValidator =
        _experiencename1TextControllerValidator;
    experienceAbout1TextControllerValidator =
        _experienceAbout1TextControllerValidator;
    priceField1TextControllerValidator = _priceField1TextControllerValidator;
    navbarForhostModel = createModel(context, () => NavbarForhostModel());
  }

  @override
  void dispose() {
    experiencename1FocusNode?.dispose();
    experiencename1TextController?.dispose();

    experienceAbout1FocusNode?.dispose();
    experienceAbout1TextController?.dispose();

    priceField1FocusNode?.dispose();
    priceField1TextController?.dispose();

    textField11FocusNode?.dispose();
    textField11TextController?.dispose();

    textField22FocusNode?.dispose();
    textField22TextController?.dispose();

    navbarForhostModel.dispose();
  }

  /// Additional helper methods.
  String? get categoryPickerValue => categoryPickerValueController?.value;
  String? get ageField1Value => ageField1ValueController?.value;
  String? get genderValue => genderValueController?.value;
}
