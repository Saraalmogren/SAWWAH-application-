import '/auth/firebase_auth/auth_util.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'resend_email_v_widget.dart' show ResendEmailVWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ResendEmailVModel extends FlutterFlowModel<ResendEmailVWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
