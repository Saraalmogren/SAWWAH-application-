import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'payment2_copy_widget.dart' show Payment2CopyWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Payment2CopyModel extends FlutterFlowModel<Payment2CopyWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for EmailsofUsers widget.
  FocusNode? emailsofUsersFocusNode;
  TextEditingController? emailsofUsersTextController;
  String? Function(BuildContext, String?)? emailsofUsersTextControllerValidator;
  String? _emailsofUsersTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (!RegExp('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}\$')
        .hasMatch(val)) {
      return 'Invalid, please enter a valid email';
    }
    return null;
  }

  @override
  void initState(BuildContext context) {
    emailsofUsersTextControllerValidator =
        _emailsofUsersTextControllerValidator;
  }

  @override
  void dispose() {
    emailsofUsersFocusNode?.dispose();
    emailsofUsersTextController?.dispose();
  }
}
