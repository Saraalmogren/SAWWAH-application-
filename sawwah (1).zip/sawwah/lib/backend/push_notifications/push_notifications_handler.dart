import 'dart:async';
import 'dart:convert';

import 'serialization_util.dart';
import '../backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../../index.dart';
import '../../main.dart';

final _handledMessageIds = <String?>{};

class PushNotificationsHandler extends StatefulWidget {
  const PushNotificationsHandler({Key? key, required this.child})
      : super(key: key);

  final Widget child;

  @override
  _PushNotificationsHandlerState createState() =>
      _PushNotificationsHandlerState();
}

class _PushNotificationsHandlerState extends State<PushNotificationsHandler> {
  bool _loading = false;

  Future handleOpenedPushNotification() async {
    if (isWeb) {
      return;
    }

    final notification = await FirebaseMessaging.instance.getInitialMessage();
    if (notification != null) {
      await _handlePushNotification(notification);
    }
    FirebaseMessaging.onMessageOpenedApp.listen(_handlePushNotification);
  }

  Future _handlePushNotification(RemoteMessage message) async {
    if (_handledMessageIds.contains(message.messageId)) {
      return;
    }
    _handledMessageIds.add(message.messageId);

    safeSetState(() => _loading = true);
    try {
      final initialPageName = message.data['initialPageName'] as String;
      final initialParameterData = getInitialParameterData(message.data);
      final parametersBuilder = parametersBuilderMap[initialPageName];
      if (parametersBuilder != null) {
        final parameterData = await parametersBuilder(initialParameterData);
        context.pushNamed(
          initialPageName,
          pathParameters: parameterData.pathParameters,
          extra: parameterData.extra,
        );
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      safeSetState(() => _loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    SchedulerBinding.instance.addPostFrameCallback((_) {
      handleOpenedPushNotification();
    });
  }

  @override
  Widget build(BuildContext context) => _loading
      ? Container(
          color: Colors.transparent,
          child: Image.asset(
            'assets/images/Screenshot_2024-11-23_221936.png',
            fit: BoxFit.cover,
          ),
        )
      : widget.child;
}

class ParameterData {
  const ParameterData(
      {this.requiredParams = const {}, this.allParams = const {}});
  final Map<String, String?> requiredParams;
  final Map<String, dynamic> allParams;

  Map<String, String> get pathParameters => Map.fromEntries(
        requiredParams.entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
  Map<String, dynamic> get extra => Map.fromEntries(
        allParams.entries.where((e) => e.value != null),
      );

  static Future<ParameterData> Function(Map<String, dynamic>) none() =>
      (data) async => ParameterData();
}

final parametersBuilderMap =
    <String, Future<ParameterData> Function(Map<String, dynamic>)>{
  'profile_Settings': ParameterData.none(),
  'onbording': ParameterData.none(),
  'userHome': ParameterData.none(),
  'BookExperience': (data) async => ParameterData(
        allParams: {
          'experienceRef': await getDocumentParameter<ExperiencesRecord>(
              data, 'experienceRef', ExperiencesRecord.fromSnapshot),
          'userRef': getParameter<DocumentReference>(data, 'userRef'),
          'seatlimittt': getParameter<int>(data, 'seatlimittt'),
          'remainingseatsss': getParameter<int>(data, 'remainingseatsss'),
        },
      ),
  'payment1': (data) async => ParameterData(
        allParams: {
          'experienceRef':
              getParameter<DocumentReference>(data, 'experienceRef'),
          'numberOfSeats': getParameter<int>(data, 'numberOfSeats'),
        },
      ),
  'payment2': ParameterData.none(),
  'CreateNewExperience': ParameterData.none(),
  'ReservationConfirmed': ParameterData.none(),
  'HostHomePage': ParameterData.none(),
  'CreateExperienceConfirmation': ParameterData.none(),
  'profile_Settings_host': ParameterData.none(),
  'auth2_profile': ParameterData.none(),
  'AuthEDITED': ParameterData.none(),
  'UserInfooo': (data) async => ParameterData(
        allParams: {
          'nameee': getParameter<DocumentReference>(data, 'nameee'),
        },
      ),
  'AuthNew': ParameterData.none(),
  'Exp_Details': (data) async => ParameterData(
        allParams: {
          'experienceDetails':
              getParameter<DocumentReference>(data, 'experienceDetails'),
        },
      ),
  'Exp_DetailsFor_Creator': (data) async => ParameterData(
        allParams: {
          'experienceDetails':
              getParameter<DocumentReference>(data, 'experienceDetails'),
        },
      ),
  'accounD': (data) async => ParameterData(
        allParams: {
          'userData': getParameter<DocumentReference>(data, 'userData'),
        },
      ),
  'resendEmailV': ParameterData.none(),
  'notificationsDrawer': ParameterData.none(),
  'users_booked_ex': ParameterData.none(),
  'Location': (data) async => ParameterData(
        allParams: {
          'locationParameter': getParameter<LatLng>(data, 'locationParameter'),
          'userLong': getParameter<double>(data, 'userLong'),
          'userlat': getParameter<double>(data, 'userlat'),
        },
      ),
  'payment2Copy': (data) async => ParameterData(
        allParams: {
          'countcontrollerguest':
              getParameter<int>(data, 'countcontrollerguest'),
          'expreffffffff': await getDocumentParameter<ExperiencesRecord>(
              data, 'expreffffffff', ExperiencesRecord.fromSnapshot),
        },
      ),
  'RecreateExp': (data) async => ParameterData(
        allParams: {
          'expName': getParameter<String>(data, 'expName'),
          'expDescription': getParameter<String>(data, 'expDescription'),
          'expImage': getParameter<String>(data, 'expImage'),
          'expAge': getParameter<String>(data, 'expAge'),
          'expPrice': getParameter<double>(data, 'expPrice'),
          'expLocation': getParameter<LatLng>(data, 'expLocation'),
          'expRef': getParameter<DocumentReference>(data, 'expRef'),
          'creatorRef': getParameter<DocumentReference>(data, 'creatorRef'),
          'expGenderr': getParameter<String>(data, 'expGenderr'),
        },
      ),
  'map': ParameterData.none(),
  'acountD_for_user': (data) async => ParameterData(
        allParams: {
          'userData': getParameter<DocumentReference>(data, 'userData'),
        },
      ),
  'User_ReservedExperiences': (data) async => ParameterData(
        allParams: {},
      ),
  'review_for_user': (data) async => ParameterData(
        allParams: {
          'experienceToRate':
              getParameter<DocumentReference>(data, 'experienceToRate'),
        },
      ),
  'review_Exp_Confirmation': ParameterData.none(),
  'Notifications': ParameterData.none(),
  'reviews1': (data) async => ParameterData(
        allParams: {
          'experID': getParameter<DocumentReference>(data, 'experID'),
        },
      ),
  'TermsandConditions': ParameterData.none(),
  'ContacttheSupportteam': ParameterData.none(),
  'image_Details': (data) async => ParameterData(
        allParams: {
          'chatMessage': await getDocumentParameter<ChatMessagesRecord>(
              data, 'chatMessage', ChatMessagesRecord.fromSnapshot),
        },
      ),
  'chat_2_Details': (data) async => ParameterData(
        allParams: {
          'chatRef': await getDocumentParameter<ChatsRecord>(
              data, 'chatRef', ChatsRecord.fromSnapshot),
        },
      ),
  'chat_2_main': ParameterData.none(),
  'chat_2_InviteUsers': (data) async => ParameterData(
        allParams: {
          'chatRef': await getDocumentParameter<ChatsRecord>(
              data, 'chatRef', ChatsRecord.fromSnapshot),
        },
      ),
  'image_Details_1': (data) async => ParameterData(
        allParams: {
          'chatMessage': await getDocumentParameter<ChatMessagesRecord>(
              data, 'chatMessage', ChatMessagesRecord.fromSnapshot),
        },
      ),
  'userHomeCopy2': ParameterData.none(),
};

Map<String, dynamic> getInitialParameterData(Map<String, dynamic> data) {
  try {
    final parameterDataStr = data['parameterData'];
    if (parameterDataStr == null ||
        parameterDataStr is! String ||
        parameterDataStr.isEmpty) {
      return {};
    }
    return jsonDecode(parameterDataStr) as Map<String, dynamic>;
  } catch (e) {
    print('Error parsing parameter data: $e');
    return {};
  }
}
